const quote=s=>"'"+s.replaceAll("'","'\\''")+"'";
async function cli(cmd,max=1200){let r=await tools.exec_command({cmd,login:false,max_output_tokens:max,yield_time_ms:1000});let out=r.output||'';while(r.session_id){r=await tools.write_stdin({session_id:r.session_id,chars:'',yield_time_ms:1000,max_output_tokens:max});out+=r.output||'';}if(r.exit_code!==0)throw Error(out.slice(-2000));return out;}
async function missing(n){return JSON.parse(await cli('python -c '+quote("import json,pathlib;p=pathlib.Path('/workspace/variant_work');a=json.loads((p/'recovery_plan.json').read_text());print(json.dumps([j['index'] for j in a if j['part']=='Part_"+n+"' and not(p/'results'/f\"{j['index']:03}.json\").exists()]))"),1200));}
for(let n=296;n<=298;n++){
 if((await cli('python -c '+quote("from pathlib import Path;print(Path('/workspace/variant_work/published/Part_"+n+".json').exists())"),100)).trim()==='True')continue;
 let todo=await missing(n),errors=[];
 for(let pass=0;pass<2&&todo.length;pass++){
  let cursor=0,attempted=0;
  async function worker(){while(cursor<todo.length){const i=todo[cursor++];let stage='preflight';try{const d=JSON.parse(await cli('python /workspace/variant_work/recovery_worker.py preflight '+i,4000));if(d.done)continue;stage='image_generation';const args={prompt:d.prompt,transparent_background:false};if(d.reference)args.referenced_image_paths=[d.reference];const r=await tools.image_gen__imagegen(args);const path=r.output_hint?.match(/\/workspace\/generated_images\/[^\s]+\.png/)?.[0];if(!path)throw Error('Generated image path missing');stage='save';await cli('python /workspace/variant_work/recovery_worker.py save '+i+' '+quote(path),400);}catch(e){errors.push({index:i,stage,error:String(e)});}attempted++;if(attempted%25===0)notify({part:n,pass:pass+1,attempted});if(attempted%10===0&&attempted<todo.length){try{const checkpoint=await cli('python /workspace/variant_work/checkpoint_recovery.py Part_'+n+' > /workspace/variant_work/checkpoint'+n+'.log 2>&1',500);notify({part:n,recovery_checkpoint:true});}catch(e){errors.push({stage:'checkpoint',error:String(e)});}}}}
  await Promise.allSettled(Array.from({length:Math.min(8,todo.length)},worker));todo=await missing(n);
 }
 if(todo.length){text({stopped:true,part:n,missing:todo,errors});exit();}
 try{await cli('python /workspace/variant_work/publish_recovery.py Part_'+n+' > /workspace/variant_work/publish'+n+'.log 2>&1',600);}catch(e){text({stopped:true,part:n,error:String(e)});exit();}
 notify({completed:JSON.parse(await cli('cat /workspace/variant_work/published/Part_'+n+'.json',1000))});
}
text({all_remaining_parts_completed:true});
