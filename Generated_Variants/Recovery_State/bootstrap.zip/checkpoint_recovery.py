from recovery_common import *
from PIL import Image
import sys,zipfile,fcntl

part=sys.argv[1]
with (P/'checkpoint.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 jobs=[j for j in load(P/'recovery_plan.json') if j['part']==part]
 ready=[]
 for j in jobs:
  f=P/'results'/f'{j["index"]:03}.json'
  if f.exists():
   r=load(f)['row'];image=ROOT/r[OUT]
   assert canon(r[SKU]) not in exclusion() and sha(image)==r['SHA-256 خروجی']
   with Image.open(image) as im:assert im.format=='JPEG' and im.mode=='RGB' and im.size==(800,800)
   ready.append((j,f,r))
 assert ready
 dest=D/part;dest.mkdir(exist_ok=True)
 rows=[r for j,f,r in ready]
 writecsv(dest/f'{part}_report.csv',rows,headers(D/'Part_295/Part_295_report.csv'))
 dump(dest/f'{part}_status.json',{'part':part,'part_size':100,'planned_variant_SKUs':len(jobs),'generated_files':len(rows),'not_generated':len(jobs)-len(rows),'complete':len(rows)==len(jobs),'checkpoint_only':True,'QC_approved':0,'all_AI_QC_pending':True,'shopify_uploads':0})
 manifest,statepaths=persist_recovery_state(part,jobs,ready)
 paths=[r[OUT] for j,f,r in ready]+[str((dest/f'{part}_report.csv').relative_to(ROOT)),str((dest/f'{part}_status.json').relative_to(ROOT))]+statepaths
 run('git','-C',str(ROOT),'add',*paths)
 if output('git','-C',str(ROOT),'diff','--cached','--name-only'):run('git','-C',str(ROOT),'commit','-m',f'Checkpoint {part}: {len(rows)}/{len(jobs)} QC-pending images for recovery')
 run('python',str(P/'aggregate_recovery.py'),part)
 reports=['Overall_report.csv','Latest_variant_status.csv','Latest_product_status.csv','Parts_summary.csv','Catalog_products_index.csv','Needs_reference_review.csv','Unusable_until_corrected.csv','Remaining_100_product_batches.csv','All_remaining_variants_queue.csv','All_remaining_products_queue.csv','Validation_summary.json','Full_scope_status.json','Delivery_status.csv','Brand_SKU_coverage_summary.json','Cross_brand_SKU_coverage_catchup.csv','Workbook_reference_audit_summary.json','Recovery_reference_screening.csv','Recovery_provenance.json']
 run('git','-C',str(ROOT),'add',*['Generated_Variants/'+n for n in reports])
 if output('git','-C',str(ROOT),'diff','--cached','--name-only'):run('git','-C',str(ROOT),'commit','-m',f'Update recovery counts for partial {part}; QC pending')
 network('git','-C',str(ROOT),'push','origin',BRANCH)
 head=output('git','-C',str(ROOT),'rev-parse','HEAD');assert network('git','-C',str(ROOT),'ls-remote','origin','refs/heads/'+BRANCH).split()[0]==head
 dump(P/'last_checkpoint.json',dict(manifest,commit=head))
 print(json.dumps(dict(manifest,commit=head)))
