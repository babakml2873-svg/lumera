import csv, json, re, hashlib, subprocess, io
from pathlib import Path

P=Path('/workspace/variant_work')
ROOT=Path('/workspace/lumera_publish')
D=ROOT/'Generated_Variants'
SOURCE=Path('/workspace/lumera')
BASE='22d81bfc2b60b79cea477ebd0c7b4f90d8faec42'
BRANCH='generated-variants-20261106'
REMOTE='https://github.com/babakml2873-svg/lumera'
QC_PENDING='نیازمند تأیید QC'
OUT='مسیر فایل خروجی در مخزن'
SKU='SKU هدف'
URL='لینک محصول'
BRAND='برند'
ISSUE='توضیح مشکل یا دلیل نیاز به بررسی'
def canon(x):return str(x or '').strip().lstrip("'").upper()
def norm(x):return re.sub('[^a-z0-9]','',str(x or '').lower())
def key(b,s):return norm(b),canon(s)
def readcsv(path):
 with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def headers(path):
 with Path(path).open(encoding='utf-8-sig',newline='') as f:return next(csv.reader(f))
def writecsv(path,rows,fields=None):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 if fields is None:fields=headers(path) if path.exists() else list(rows[0])
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
def dump(path,obj):
 path=Path(path);tmp=path.with_name(path.name+'.tmp')
 tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)
def load(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def exclusion():
 x={canon(r['sku']) for r in readcsv(next(Path('/workspace/attachments').glob('*/*.csv')))}
 assert len(x)==184
 return x
def run(*args):return subprocess.run(args,check=True,text=True)
def output(*args):return subprocess.check_output(args,text=True).strip()
def network(*args):
 for attempt in range(3):
  try:return output(*args)
  except subprocess.CalledProcessError:
   if attempt==2:raise
def safe(x):return re.sub(r'[\s/\\:?#&]+','-',str(x)).strip('-')
def existing_rows():
 rows=[]
 for f in sorted(D.glob('Part_*/*_report.csv')):
  rows.extend(dict({'پارت':f.parent.name},**r) for r in readcsv(f))
 return rows
def generated_rows():return [r for r in existing_rows() if r.get(OUT)]
