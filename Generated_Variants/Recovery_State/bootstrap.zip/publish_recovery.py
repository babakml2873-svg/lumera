from recovery_common import *
from PIL import Image
import sys,fcntl

part=sys.argv[1]
publication_lock=(P/'checkpoint.lock').open('a+')
fcntl.flock(publication_lock,fcntl.LOCK_EX)
jobs=[j for j in load(P/'recovery_plan.json') if j['part']==part]
assert len(jobs)==(91 if part=='Part_298' else 100)
assert output('git','-C',str(ROOT),'branch','--show-current')==BRANCH
rs=[]
for j in jobs:
 assert canon(j['row']['SKU']) not in exclusion()
 result=load(P/'results'/f'{j["index"]:03}.json');r=result['row'];f=ROOT/r[OUT]
 assert r[OUT]==j['path'] and key(r[BRAND],r[SKU])==key(j['row']['برند'],j['row']['SKU'])
 assert r['وضعیت QC']==QC_PENDING and r['وضعیت تولید']==j['production_status']
 with Image.open(f) as im:assert im.size==(800,800) and im.mode=='RGB' and im.format=='JPEG'
 assert f.stat().st_size==int(r['حجم فایل خروجی (بایت)'])<=100000 and sha(f)==r['SHA-256 خروجی']
 assert f.name==safe(r[SKU])+'-V.jpg'
 if j['ref']:assert result['reference_sha256']==j['ref']['sha256']==sha(SOURCE/j['ref']['path'])
 rs.append(r)
assert len({key(r[BRAND],r[SKU]) for r in rs})==len(rs)
old=[r for r in generated_rows() if r['پارت']!=part]
assert not {key(r[BRAND],r[SKU]) for r in rs}&{key(r[BRAND],r[SKU]) for r in old}
dest=D/part;dest.mkdir(exist_ok=True)
assert {str(f.relative_to(ROOT)) for f in dest.rglob('*.jpg')}=={r[OUT] for r in rs}
writecsv(dest/f'{part}_report.csv',rs,headers(D/'Part_295/Part_295_report.csv'))
dump(dest/f'{part}_status.json',{'part':part,'part_size':100,'planned_variant_SKUs':len(jobs),'planned_unique_QC_sheet_product_URLs':len({r[URL] for r in rs}),'generated_files':len(rs),'not_generated':0,'generation_errors':0,'complete':True,'QC_approved':0,'unusable_until_exact_SKU_verification':len(rs),'reference_based_images':sum(j['ref'] is not None for j in jobs),'unreferenced_concepts':sum(j['ref'] is None for j in jobs),'source':'Immutable original GitHub reference files only; unreferenced concepts are unusable pending a real exact-SKU photograph.','shopify_uploads':0})
if not output('git','-C',str(ROOT),'config','user.name'):raise AssertionError('Git author not configured')
manifest,statepaths=persist_recovery_state(part,jobs,[(j,P/'results'/f'{j["index"]:03}.json',r) for j,r in zip(jobs,rs)])
run('git','-C',str(ROOT),'add','Generated_Variants/'+part,*statepaths)
if output('git','-C',str(ROOT),'diff','--cached','--name-only'):run('git','-C',str(ROOT),'commit','-m',f'Add {part}: {len(rs)} recovered variant drafts requiring exact-SKU QC')
commit=output('git','-C',str(ROOT),'log','-1','--diff-filter=A','--format=%H','--','Generated_Variants/'+part)
run('python',str(P/'aggregate_recovery.py'),part)
if part=='Part_298':run('python',str(P/'audit_recovery_delivery.py'))
reportnames=['Overall_report.csv','Latest_variant_status.csv','Latest_product_status.csv','Parts_summary.csv','Catalog_products_index.csv','Needs_reference_review.csv','Unusable_until_corrected.csv','Remaining_100_product_batches.csv','All_remaining_variants_queue.csv','All_remaining_products_queue.csv','Validation_summary.json','Full_scope_status.json','Delivery_status.csv','Brand_SKU_coverage_summary.json','Cross_brand_SKU_coverage_catchup.csv','Workbook_reference_audit_summary.json','Recovery_reference_screening.csv','Recovery_provenance.json']
if part=='Part_298':reportnames.append('Final_delivery_audit.json')
run('git','-C',str(ROOT),'add',*['Generated_Variants/'+n for n in reportnames])
if output('git','-C',str(ROOT),'diff','--cached','--name-only'):run('git','-C',str(ROOT),'commit','-m',f'Finalize missing-variant generation and audit after {part}; QC pending' if part=='Part_298' else f'Update aggregate and recovery reports after {part}')
changed=subprocess.check_output(['git','-C',str(ROOT),'diff','--name-status','-z',BASE,'HEAD'],text=True).split('\0')[:-1]
assert all(changed[i]=='A' and changed[i+1].startswith('Generated_Variants/') for i in range(0,len(changed),2))
network('git','-C',str(ROOT),'push','origin',BRANCH)
head=output('git','-C',str(ROOT),'rev-parse','HEAD');assert network('git','-C',str(ROOT),'ls-remote','origin','refs/heads/'+BRANCH).split()[0]==head
assert not output('git','-C',str(ROOT),'status','--porcelain')
result={'part':part,'generated':len(rs),'QC_pending':len(rs),'commit':commit,'aggregate_commit':head,'folder':REMOTE+'/tree/'+BRANCH+'/Generated_Variants/'+part}
dump(P/'published'/f'{part}.json',result);print(json.dumps(result))
pause=P/'pause_after_part.json'
if pause.exists() and load(pause).get('part')==part:
 print('CONTROLLED_HANDOFF: complete part published; restart controller with reduced concurrency',flush=True)
 sys.exit(75)
