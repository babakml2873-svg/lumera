from recovery_common import *
from PIL import Image

rows=generated_rows();paths={r[OUT] for r in rows};files={str(f.relative_to(ROOT)) for f in D.rglob('*.jpg')}
assert len(rows)==len(paths)==len(files)==16991 and paths==files
assert len({key(r[BRAND],r[SKU]) for r in rows})==16991
assert not {canon(r[SKU]) for r in rows}&exclusion()
assert len({r[URL].rstrip('/') for r in rows})==12197
for r in rows:
 f=ROOT/r[OUT]
 with Image.open(f) as im:assert im.format=='JPEG' and im.size==(800,800) and im.mode=='RGB',r[OUT]
 assert f.stat().st_size==int(r['حجم فایل خروجی (بایت)'])<=100000,r[OUT]
 assert r['وضعیت QC']==QC_PENDING,r[OUT]
 assert f.name==safe(r[SKU])+'-V.jpg',r[OUT]
 if r.get('SHA-256 خروجی'):assert sha(f)==r['SHA-256 خروجی'],r[OUT]
changed=subprocess.check_output(['git','-C',str(ROOT),'diff','--name-status','-z',BASE,'HEAD'],text=True).split('\0')[:-1]
assert all(changed[i]=='A' and changed[i+1].startswith('Generated_Variants/') for i in range(0,len(changed),2))
recovery=load(P/'recovery_plan.json');assert all((P/'results'/f'{j["index"]:03}.json').exists() for j in recovery)
assert len(recovery)==291 and not readcsv(D/'Remaining_100_product_batches.csv')
coverage=load(D/'Brand_SKU_coverage_summary.json');assert coverage['eligible_brand_SKUs_not_yet_generated']==coverage['eligible_brand_SKUs_not_planned']==0
assert len(readcsv(D/'All_remaining_variants_queue.csv'))==216
out={'generated_variant_images':16991,'distinct_QC_sheet_product_URLs':12197,'maximum_output_bytes':max((ROOT/x).stat().st_size for x in paths),'exact_dimensions':[800,800],'format':'RGB JPEG .jpg','QC_approved':0,'all_AI_outputs_require_exact_SKU_QC':True,'excluded_184_sku_overlap':0,'baseline_files_modified_or_deleted':0,'all_branch_additions_under_Generated_Variants':True,'existing_V_conflicts_for_separate_review':216,'uncertain_QC_rows_for_separate_review':11659,'shopify_uploads':0,'eligible_confirmed_missing_brand_SKUs':16983,'eligible_confirmed_missing_brand_SKUs_not_generated':0,'earlier_generated_SKUs_from_uncertain_V_rows':8,'identity_is_brand_plus_SKU':True,'eligible_planned_missing_variant_jobs_remaining':0,'recovered_last_parts':[296,297,298],'recovery_reference_sources_visually_reviewed':48,'scope_note':'Completion covers selected confirmed-missing identities, not QC approval. Existing-V conflicts and uncertain rows remain separate review cases. Unreferenced concepts, unverified variants and known-error outputs remain unusable until verified/corrected.'}
dump(D/'Final_delivery_audit.json',out);print(json.dumps(out,ensure_ascii=False))
