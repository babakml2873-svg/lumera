from recovery_common import *
import sys
from PIL import Image,ImageOps

mode=sys.argv[1]
if mode=='status':
 jobs=load(P/'recovery_plan.json')
 pub={f.stem for f in (P/'published').glob('Part_*.json')}
 part=next((j['part'] for j in jobs if j['part'] not in pub),None)
 completed=16700+sum(sum(j['part']==n for j in jobs) for n in pub)
 checkpoint=load(P/'last_checkpoint.json') if (P/'last_checkpoint.json').exists() else None
 checkpoint_total=16700+sum(int(j['part'].split('_')[1])<int(checkpoint['active_part'].split('_')[1]) for j in jobs)+checkpoint['saved_images_in_active_part'] if checkpoint else 16700
 print(json.dumps({'part':part,'saved':sum((P/'results'/f'{j["index"]:03}.json').exists() for j in jobs if j['part']==part),'target':sum(j['part']==part for j in jobs),'completed_part_images':completed,'published_images_including_partial_checkpoints':max(completed,checkpoint_total),'all_generated_results':sum((P/'results'/f'{j["index"]:03}.json').exists() for j in jobs)}))
 sys.exit()
i=int(sys.argv[2]);j=load(P/'jobs'/f'{i:03}.json');result=P/'results'/f'{i:03}.json'
assert canon(j['row']['SKU']) not in exclusion()
assert j['row']['عدم وجود تصویر برای واریانت'].startswith(('بله','فقط عکس گالری'))
if mode=='preflight':
 if result.exists():print(json.dumps({'done':True}));sys.exit()
 assert not (ROOT/j['path']).exists()
 if j['ref']:
  r=j['ref'];assert r['review']['visually_reviewed'] and r['review']['state']=='suitable_structural_draft'
  assert sha(SOURCE/r['path'])==r['sha256']
 print(json.dumps({'done':False,'prompt':j['prompt'],'reference':str(SOURCE/j['ref']['path']) if j['ref'] else None},ensure_ascii=False))
elif mode=='save':
 assert not result.exists() and not (ROOT/j['path']).exists()
 raw=Path(sys.argv[3]);assert raw.parent==Path('/workspace/generated_images') and raw.suffix=='.png'
 with Image.open(raw) as image:
  rgba=ImageOps.contain(image.convert('RGBA'),(800,800),Image.Resampling.LANCZOS)
  out=Image.new('RGB',(800,800),'white');out.paste(rgba,((800-rgba.width)//2,(800-rgba.height)//2),rgba.getchannel('A'))
  data=None
  for quality in range(95,19,-5):
   b=io.BytesIO();out.save(b,format='JPEG',quality=quality,optimize=True,subsampling=0)
   if len(b.getvalue())<=100000:data=b.getvalue();break
  assert data is not None
 f=ROOT/j['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 r=j['row'];cat=[x.strip() for x in r['دسته‌بندی'].split(' / ') if x.strip()]
 row={'نام محصول':r['نام محصول'],BRAND:r['برند'],'دسته‌بندی':cat[0],'زیردسته':' / '.join(cat[1:]),SKU:str(r['SKU']),'ویژگی یا رنگ واریانت هدف':'رنگ/پرداخت هدف مستند نشد؛ حفظ رنگ مرجع' if j['ref'] else 'ویژگی‌های نام محصول؛ رنگ تأییدنشده',URL:r['لینک محصول'],'SKU مرجع':j['ref']['sku'] if j['ref'] else 'بدون مرجع معتبر محصول','لینک تصویر مرجع گیت‌هاب':j['ref']['url'] if j['ref'] else '',OUT:j['path'],'ابعاد فایل خروجی':'800 x 800','حجم فایل خروجی (بایت)':len(data),'وضعیت تولید':j['production_status'],'وضعیت QC':QC_PENDING,ISSUE:j['issue'],'منبع مشخصات هدف':f"Supplied QC workbook exact row: {r['SKU']} | {r['نام محصول']} | {r['لینک محصول']}"+(' | Source immutable GitHub SHA256 '+j['ref']['sha256'] if j['ref'] else ''),'SHA-256 خروجی':hashlib.sha256(data).hexdigest(),'وضعیت بررسی بصری':'pending'}
 dump(result,{'index':i,'row':row,'raw_path':str(raw),'reference_sha256':j['ref']['sha256'] if j['ref'] else None})
 print(json.dumps({'index':i,'saved':True,'bytes':len(data)}))
else:raise ValueError(mode)
