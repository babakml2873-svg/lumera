from recovery_common import *
from collections import Counter
import sys,datetime

part=sys.argv[1];last=int(part.split('_')[1]);snap=P/'remote_recovery_baseline';jobs=load(P/'recovery_plan.json')
new=[]
for n in range(296,last+1):
 f=D/f'Part_{n}'/f'Part_{n}_report.csv'
 if f.exists():new.extend(dict({'پارت':f'Part_{n}'},**r) for r in readcsv(f))
overall=readcsv(snap/'Overall_report.csv')+new
latest={key(r[BRAND],r[SKU]):r for r in readcsv(snap/'Latest_variant_status.csv')}
latest.update({key(r[BRAND],r[SKU]):r for r in new})
current=list(latest.values());gen=[r for r in current if r.get(OUT)];keys={key(r[BRAND],r[SKU]) for r in gen}
assert len(gen)==16700+len(new) and len({r[OUT] for r in gen})==len(gen)
assert len(generated_rows())==len(gen)
doneurls={r[URL].rstrip('/') for r in gen};remaining=[j for j in jobs if key(j['row']['برند'],j['row']['SKU']) not in keys]
newurls={j['row']['لینک محصول'].rstrip('/') for j in remaining}-doneurls
report_fields=headers(snap/'Latest_variant_status.csv')
writecsv(D/'Overall_report.csv',overall,report_fields)
writecsv(D/'Latest_variant_status.csv',current,report_fields)
unusable=lambda r:'غیرقابل استفاده' in r['وضعیت تولید']
needsref=lambda r:not r['لینک تصویر مرجع گیت‌هاب'] or 'نیازمند بررسی مرجع' in r[ISSUE]
writecsv(D/'Unusable_until_corrected.csv',[r for r in current if unusable(r)],report_fields)
writecsv(D/'Needs_reference_review.csv',[r for r in current if needsref(r)],report_fields)
per=Counter(r[URL].rstrip('/') for r in gen);bad=Counter(r[URL].rstrip('/') for r in gen if unusable(r))
products={r[URL].rstrip('/'):r for r in current};productrows=[]
for url,r in products.items():productrows.append(dict(r,**{'تعداد SKU دارای فایل تولیدشده':per[url],'تعداد تصاویر غیرقابل استفاده تا اصلاح یا تطبیق':bad[url],'تعداد تصاویر تأییدشده QC':0}))
writecsv(D/'Latest_product_status.csv',productrows,headers(snap/'Latest_product_status.csv'))
lastgen={r[URL].rstrip('/'):r for r in gen}
index=[{'ردیف':i+1,'لینک محصول یکتای شیت':u,'نام محصول':r['نام محصول'],BRAND:r[BRAND],'SKU آخرین تصویر':r[SKU],'تعداد SKU دارای فایل':per[u],'پارت آخرین تصویر':r['پارت'],'وضعیت QC':QC_PENDING} for i,(u,r) in enumerate(lastgen.items())]
writecsv(D/'Catalog_products_index.csv',index,headers(snap/'Catalog_products_index.csv'))
parts=readcsv(snap/'Parts_summary.csv')
for n in range(296,last+1):
 name=f'Part_{n}';rs=[r for r in new if r['پارت']==name]
 if not rs:continue
 commit=output('git','-C',str(ROOT),'log','-1','--diff-filter=A','--format=%H','--',f'Generated_Variants/{name}')
 parts.append({'پارت':name,'ردیف SKU بررسی‌شده':len(rs),'محصول یکتای شیت':len({r[URL] for r in rs}),'تصویر تولیدشده':len(rs),'غیرقابل استفاده تا اصلاح':sum(unusable(r) for r in rs),'commit':commit,'لینک پوشه':REMOTE+'/tree/'+BRANCH+'/Generated_Variants/'+name})
writecsv(D/'Parts_summary.csv',parts,headers(snap/'Parts_summary.csv'))
writecsv(D/'Remaining_100_product_batches.csv',[j['queue_row'] for j in remaining],headers(snap/'Remaining_100_product_batches.csv'))
varqueue=[r for r in readcsv(snap/'All_remaining_variants_queue.csv') if key(r[BRAND],r[SKU]) not in keys]
productqueue=[r for r in readcsv(snap/'All_remaining_products_queue.csv') if key(r[BRAND],r[SKU]) not in keys]
writecsv(D/'All_remaining_variants_queue.csv',varqueue,headers(snap/'All_remaining_variants_queue.csv'))
writecsv(D/'All_remaining_products_queue.csv',productqueue,headers(snap/'All_remaining_products_queue.csv'))
summary=load(snap/'Validation_summary.json')
summary.update({'target_products':12197,'target_variant_images':16991,'target_completed':not remaining,'images_generated':len(gen),'queue_generated':len(gen),'distinct_sheet_products_with_generated_images':len(doneurls),'products_reviewed_unique':len(products),'part_report_rows_including_rechecks':len(overall),'remaining_planned_products':len(newurls),'remaining_planned_variant_images':len(remaining),'queue_unverified_future_candidates':len(remaining),'needs_reference_review_unique':sum(needsref(r) for r in current),'unusable_until_corrected':sum(unusable(r) for r in gen),'generated_without_reference':sum(not r['لینک تصویر مرجع گیت‌هاب'] for r in gen),'images_without_known_obvious_error':sum(not unusable(r) for r in gen),'qc_approved_images':0,'all_generated_require_qc_approval':True,'maximum_output_bytes':max(int(r['حجم فایل خروجی (بایت)']) for r in gen),'production_status':'Selected missing-variant generation queue completed; all AI outputs require exact-SKU QC and unverified drafts remain unusable until verified or corrected.' if not remaining else 'In progress, 100 SKU images per part; final remainder may be smaller. All AI outputs require exact-SKU QC.','recovery_reference_source_screening':'Recovery_reference_screening.csv'})
dump(D/'Validation_summary.json',summary)
scope=load(snap/'Full_scope_status.json')
scope.update({'generated_catalog_products':len(doneurls),'generated_variant_images':len(gen),'remaining_distinct_new_catalog_product_urls':len(productqueue),'remaining_missing_variant_skus_including_other_variants_of_generated_products':len(varqueue),'eligible_remaining_variant_generation_jobs':len(remaining),'planned_eligible_variant_images_remaining':len(remaining),'planned_eligible_new_products_remaining':len(newurls),'remaining_planned_products':len(newurls),'remaining_planned_variant_images':len(remaining),'all_AI_QC_pending':True})
dump(D/'Full_scope_status.json',scope)
delivery=readcsv(snap/'Delivery_status.csv')[0]
delivery.update({'محصول دارای فایل':len(doneurls),'تصویر SKU تولیدشده':len(gen),'باقی‌مانده تصویر صف انتخاب‌شده':len(remaining),'وضعیت':'در حال انجام' if remaining else 'تولید صف انتخاب‌شده تکمیل شد؛ QC باقی است','تأییدشده QC':0})
writecsv(D/'Delivery_status.csv',[delivery],headers(snap/'Delivery_status.csv'))
conflicts={key(r[BRAND],r[SKU]) for r in readcsv(D/'Existing_variant_image_conflicts_review.csv')}
qc=load(P/'qc.json');ex=exclusion()
eligible={key(r['برند'],r['SKU']) for r in qc if r['عدم وجود تصویر برای واریانت'].startswith(('بله','فقط عکس گالری')) and canon(r['SKU']) not in ex and key(r['برند'],r['SKU']) not in conflicts}
assert len(eligible)==16983 and len(keys-eligible)==8
assert eligible-keys=={key(j['row']['برند'],j['row']['SKU']) for j in remaining}
coverage=load(snap/'Brand_SKU_coverage_summary.json');coverage.update({'generated_eligible_confirmed_missing_brand_SKUs':len(eligible&keys),'eligible_brand_SKUs_not_yet_generated':len(eligible-keys),'current_generated_image_files':len(gen)})
dump(D/'Brand_SKU_coverage_summary.json',coverage)
cross=readcsv(snap/'Cross_brand_SKU_coverage_catchup.csv');bykey={key(r[BRAND],r[SKU]):r for r in gen}
for r in cross:
 k=key(r['برند هدف'],r[SKU])
 if k in bykey:
  a=bykey[k];r.update({'SKU مرجع تصویر':a['SKU مرجع'],'لینک مرجع گیت‌هاب':a['لینک تصویر مرجع گیت‌هاب'],'مسیر خروجی':a[OUT],'وضعیت تولید':a['وضعیت تولید'],'وضعیت QC':QC_PENDING,'توضیح':a[ISSUE]})
writecsv(D/'Cross_brand_SKU_coverage_catchup.csv',cross,headers(snap/'Cross_brand_SKU_coverage_catchup.csv'))
workbook=load(snap/'Workbook_reference_audit_summary.json')
if key('Nora Lighting','NLCBC2-55627WW/A') in keys:workbook['reference_target_SKUs_not_yet_generated']=0
workbook['exported_UTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();workbook['additional_Git_gallery_sources_screened_after_workspace_recovery']=48
dump(D/'Workbook_reference_audit_summary.json',workbook)
manifest=load(P/'recovery_manifest.json');manifest.update({'completed_recovery_images':len(new),'remaining_recovery_images':len(remaining),'latest_reported_part':part,'generation_complete':not remaining,'all_AI_requires_QC':True,'QC_approved':0})
dump(D/'Recovery_provenance.json',manifest)
print(json.dumps({'images':len(gen),'unique_products':len(doneurls),'remaining':len(remaining),'QC_approved':0}))
